package com.nova.pubg

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors

/**
 * VPN محلی فقط برای DNS: فقط آدرس DNS ساختگی (10.99.0.2) به تونل می‌رود.
 * درخواست‌های DNS خوانده و به DNS انتخاب‌شده فرستاده می‌شوند. بقیه ترافیک (از جمله خود بازی) دست‌نخورده می‌ماند.
 */
class DnsVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.nova.pubg.START"
        const val ACTION_STOP = "com.nova.pubg.STOP"
        const val EXTRA_DNS = "dns"
        const val FAKE_DNS = "10.99.0.2"
        @Volatile var running = false
    }

    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    private val pool = Executors.newCachedThreadPool()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopVpn(); stopSelf(); return START_NOT_STICKY }
        val prefs = getSharedPreferences("nova", 0)
        val dns = intent?.getStringExtra(EXTRA_DNS) ?: prefs.getString("dns", "8.8.8.8")!!
        startVpn(dns)
        return START_STICKY
    }

    private fun startVpn(dns: String) {
        stopVpn()
        val fd = Builder().setSession("NOVA DNS").addAddress("10.99.0.1", 24)
            .addDnsServer(FAKE_DNS).addRoute(FAKE_DNS, 32).setMtu(1500).establish() ?: return
        tun = fd
        running = true
        getSharedPreferences("nova", 0).edit().putString("dns", dns).apply()
        worker = Thread { loop(fd, dns) }.also { it.isDaemon = true; it.start() }
    }

    private fun stopVpn() {
        running = false
        worker?.interrupt(); worker = null
        try { tun?.close() } catch (e: Exception) { }
        tun = null
    }

    override fun onRevoke() { stopVpn(); stopSelf() }
    override fun onDestroy() { stopVpn(); pool.shutdownNow(); super.onDestroy() }

    private fun loop(fd: ParcelFileDescriptor, dns: String) {
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        val target = InetAddress.getByName(dns)
        val fake = byteArrayOf(10, 99, 0, 2)
        while (running) {
            val n = try { input.read(buf) } catch (e: Exception) { break }
            if (n < 28) continue
            if ((buf[0].toInt() shr 4) != 4 || buf[9].toInt() != 17) continue
            val ihl = (buf[0].toInt() and 0x0F) * 4
            if (n < ihl + 8) continue
            if (!(0..3).all { buf[16 + it] == fake[it] }) continue
            val dport = ((buf[ihl + 2].toInt() and 0xFF) shl 8) or (buf[ihl + 3].toInt() and 0xFF)
            if (dport != 53) continue
            val sport = ((buf[ihl].toInt() and 0xFF) shl 8) or (buf[ihl + 1].toInt() and 0xFF)
            val client = buf.copyOfRange(12, 16)
            val query = buf.copyOfRange(ihl + 8, n)
            pool.execute { forward(target, query, client, sport, output) }
        }
    }

    private fun forward(target: InetAddress, q: ByteArray, client: ByteArray, cport: Int, out: FileOutputStream) {
        try {
            DatagramSocket().use { s ->
                protect(s)
                s.soTimeout = 3000
                s.send(DatagramPacket(q, q.size, target, 53))
                val rb = ByteArray(4096)
                val r = DatagramPacket(rb, rb.size)
                s.receive(r)
                val pkt = reply(client, cport, rb.copyOf(r.length))
                synchronized(out) { out.write(pkt) }
            }
        } catch (e: Exception) { }
    }

    private fun reply(client: ByteArray, cport: Int, payload: ByteArray): ByteArray {
        val len = 28 + payload.size
        val p = ByteArray(len)
        p[0] = 0x45; p[2] = (len shr 8).toByte(); p[3] = len.toByte()
        p[6] = 0x40; p[8] = 64; p[9] = 17
        byteArrayOf(10, 99, 0, 2).copyInto(p, 12)
        client.copyInto(p, 16)
        val cs = checksum(p, 20)
        p[10] = (cs shr 8).toByte(); p[11] = cs.toByte()
        p[20] = 0; p[21] = 53
        p[22] = (cport shr 8).toByte(); p[23] = cport.toByte()
        val ul = 8 + payload.size
        p[24] = (ul shr 8).toByte(); p[25] = ul.toByte()
        payload.copyInto(p, 28)
        return p
    }

    private fun checksum(b: ByteArray, len: Int): Int {
        var sum = 0; var i = 0
        while (i < len) { sum += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF); i += 2 }
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv() and 0xFFFF
    }
}
