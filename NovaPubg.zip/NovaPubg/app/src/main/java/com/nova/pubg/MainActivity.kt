package com.nova.pubg

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/** پوسته‌ی اندروید برای همان صفحه‌ی HTML: دکمه‌ی «روشن کردن DNS» از طریق NovaNative واقعاً DNS را عوض می‌کند. */
class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var pendingIp = ""
    private var pendingName = ""
    private var pendingRes: List<DnsResult> = emptyList()

    private val vpnLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) startDns() else send(false, "اجازه‌ی VPN داده نشد")
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "NovaNative")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, req: WebResourceRequest): Boolean {
                val u = req.url.toString()
                if (u.startsWith("intent:")) {
                    try { startActivity(Intent.parseUri(u, Intent.URI_INTENT_SCHEME)) } catch (e: Exception) { }
                    return true
                }
                return false
            }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun send(ok: Boolean, msg: String, name: String = "", ip: String = "", res: List<DnsResult> = emptyList()) {
        val arr = JSONArray()
        res.forEach {
            arr.put(JSONObject().put("name", it.name).put("ms", it.avgMs ?: JSONObject.NULL).put("failed", it.failed).put("total", it.total))
        }
        val o = JSONObject().put("ok", ok).put("msg", msg).put("name", name).put("ip", ip).put("results", arr)
        runOnUiThread { web.evaluateJavascript("window.onNovaDns&&window.onNovaDns($o)", null) }
    }

    private fun startDns() {
        startService(Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_START).putExtra(DnsVpnService.EXTRA_DNS, pendingIp))
        send(true, "", pendingName, pendingIp, pendingRes)
    }

    inner class Bridge {
        @JavascriptInterface fun isDnsOn(): Boolean = DnsVpnService.running

        @JavascriptInterface fun disableDns() {
            startService(Intent(this@MainActivity, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_STOP))
        }

        @JavascriptInterface fun enableBestDns() {
            runOnUiThread {
                lifecycleScope.launch {
                    val map = Config.DNS_SERVERS.toMap()
                    val res = DnsTest.compare()
                    val best = res.filter { it.name in map && it.avgMs != null && it.failed <= 1 }.minByOrNull { it.avgMs!! }
                    if (best == null) { send(false, "هیچ DNSی جواب نداد؛ چیزی تغییر نکرد.", res = res); return@launch }
                    pendingIp = map[best.name]!!; pendingName = best.name; pendingRes = res
                    val i = VpnService.prepare(this@MainActivity)
                    if (i != null) vpnLauncher.launch(i) else startDns()
                }
            }
        }
    }
}
