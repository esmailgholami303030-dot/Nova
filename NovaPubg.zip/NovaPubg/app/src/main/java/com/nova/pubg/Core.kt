package com.nova.pubg

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

/** تنظیمات قابل ویرایش. دامنه‌های بازی را با ابزار بررسی ترافیک (مثلاً PCAPdroid) روی گوشی خودت تأیید کن. */
object Config {
    const val PING_HOST = "1.1.1.1"
    val GAME_DOMAINS = listOf("pubgmobile.com", "igamecj.com", "proximabeta.com")
    /** سه مورد آخر را از حافظه نوشته‌ام و تأیید نشده‌اند؛ آدرس‌ها را از سایت خود سرویس‌ها چک کن. تست داخل برنامه نشان می‌دهد کدام روی اینترنت تو جواب می‌دهد. */
    val DNS_SERVERS = listOf(
        "Google" to "8.8.8.8", "Cloudflare" to "1.1.1.1", "Quad9" to "9.9.9.9",
        "Shecan" to "178.22.122.100", "Radar" to "10.202.10.10", "403" to "10.202.10.202"
    )
    val PUBG_PACKAGES = listOf("com.tencent.ig", "com.pubg.krmobile", "com.vng.pubgmobile", "com.rekoo.pubgm", "com.pubg.imobile")
}

data class PingResult(val avgMs: Double?, val jitterMs: Double?, val lossPct: Double)
data class DnsResult(val name: String, val avgMs: Double?, val failed: Int, val total: Int)
data class DiagStep(val title: String, val ok: Boolean, val detail: String)
data class DeviceInfo(val tempC: Float?, val ramUsedPct: Int)

fun qualityScore(avg: Double, jitter: Double, loss: Double): Int =
    (100 - minOf(60.0, avg / 3) - minOf(20.0, jitter * 2) - minOf(40.0, loss * 4)).toInt().coerceIn(0, 100)

object NetTest {
    /** پینگ واقعی از روی زمان اتصال TCP (پورت ۴۴۳). جیتر = میانگین اختلاف پینگ‌های متوالی. */
    suspend fun ping(host: String = Config.PING_HOST, port: Int = 443, count: Int = 12): PingResult =
        withContext(Dispatchers.IO) {
            val addr = try { InetAddress.getByName(host) } catch (e: Exception) { return@withContext PingResult(null, null, 100.0) }
            val rtts = mutableListOf<Double>()
            var lost = 0
            repeat(count) {
                val t0 = System.nanoTime()
                try {
                    Socket().use { it.connect(InetSocketAddress(addr, port), 2000) }
                    rtts += (System.nanoTime() - t0) / 1e6
                } catch (e: Exception) { lost++ }
                delay(150)
            }
            if (rtts.isEmpty()) return@withContext PingResult(null, null, 100.0)
            val jitter = if (rtts.size > 1) rtts.zipWithNext { a, b -> kotlin.math.abs(b - a) }.average() else 0.0
            PingResult(rtts.average(), jitter, lost * 100.0 / count)
        }
}

object DnsTest {
    private fun query(domain: String): ByteArray {
        val o = ByteArrayOutputStream()
        val id = (0..65535).random()
        o.write(id shr 8); o.write(id and 0xFF)
        o.write(0x01); o.write(0x00)      // recursion desired
        o.write(0); o.write(1)            // QDCOUNT = 1
        repeat(6) { o.write(0) }          // AN, NS, AR = 0
        domain.split(".").forEach { o.write(it.length); o.write(it.toByteArray()) }
        o.write(0); o.write(0); o.write(1); o.write(0); o.write(1) // type A, class IN
        return o.toByteArray()
    }

    /** زمان پاسخ (ms) یا null اگر پاسخ معتبر نیامد. */
    suspend fun queryServer(server: String, domain: String): Double? = withContext(Dispatchers.IO) {
        try {
            DatagramSocket().use { s ->
                s.soTimeout = 2000
                val q = query(domain)
                val t0 = System.nanoTime()
                s.send(DatagramPacket(q, q.size, InetAddress.getByName(server), 53))
                val buf = ByteArray(512)
                val r = DatagramPacket(buf, buf.size)
                s.receive(r)
                val ms = (System.nanoTime() - t0) / 1e6
                val rcode = buf[3].toInt() and 0x0F
                val answers = ((buf[6].toInt() and 0xFF) shl 8) or (buf[7].toInt() and 0xFF)
                if (rcode == 0 && answers > 0) ms else null
            }
        } catch (e: Exception) { null }
    }

    suspend fun systemResolve(domain: String): Double? = withContext(Dispatchers.IO) {
        try {
            val t0 = System.nanoTime()
            InetAddress.getAllByName(domain)
            (System.nanoTime() - t0) / 1e6
        } catch (e: Exception) { null }
    }

    suspend fun compare(): List<DnsResult> {
        val domains = Config.GAME_DOMAINS + "google.com"
        val out = mutableListOf<DnsResult>()
        suspend fun run(name: String, fn: suspend (String) -> Double?) {
            val times = mutableListOf<Double>(); var failed = 0
            repeat(2) { for (d in domains) { val t = fn(d); if (t == null) failed++ else times += t } }
            out += DnsResult(name, times.takeIf { it.isNotEmpty() }?.average(), failed, domains.size * 2)
        }
        run("DNS فعلی گوشی") { systemResolve(it) }
        for ((n, ip) in Config.DNS_SERVERS) run(n) { queryServer(ip, it) }
        return out
    }
}

object Diagnose {
    fun hasInternet(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    /** عیب‌یابی مرحله‌ای: اینترنت ← DNS ← اتصال TCP به سرورهای بازی. */
    suspend fun run(ctx: Context): List<DiagStep> = withContext(Dispatchers.IO) {
        val steps = mutableListOf<DiagStep>()
        val net = hasInternet(ctx)
        steps += DiagStep("اینترنت", net, if (net) "اینترنت فعال و تأییدشده است" else "اینترنت وصل نیست یا به اینترنت واقعی دسترسی ندارد")
        if (!net) return@withContext steps

        val ips = mutableMapOf<String, InetAddress>()
        val failed = mutableListOf<String>()
        for (d in Config.GAME_DOMAINS) try { ips[d] = InetAddress.getByName(d) } catch (e: Exception) { failed += d }
        if (failed.isEmpty()) {
            steps += DiagStep("DNS فعلی", true, "همه دامنه‌های بازی resolve شدند")
        } else {
            val publicOk = failed.all { DnsTest.queryServer("8.8.8.8", it) != null }
            steps += DiagStep(
                "DNS فعلی", false,
                if (publicOk) "DNS فعلی این دامنه‌ها را resolve نکرد ولی DNS عمومی کرد؛ تغییر DNS احتمالاً کمک می‌کند"
                else "حتی DNS عمومی هم این دامنه‌ها را resolve نکرد؛ احتمالاً مسدودسازی در مسیر است و DNS به‌تنهایی کمکی نمی‌کند"
            )
        }

        if (ips.isNotEmpty()) {
            val bad = ips.filter { (_, ip) ->
                try { Socket().use { it.connect(InetSocketAddress(ip, 443), 3000) }; false } catch (e: Exception) { true }
            }.keys
            steps += DiagStep(
                "اتصال به سرورهای بازی", bad.isEmpty(),
                if (bad.isEmpty()) "اتصال TCP به همه برقرار شد"
                else "اتصال به ${bad.joinToString("، ")} برقرار نشد؛ مشکل از مسیر، اپراتور یا مسدودسازی است نه DNS"
            )
        }
        steps
    }
}

object Device {
    fun read(ctx: Context): DeviceInfo {
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        return DeviceInfo(if (t >= 0) t / 10f else null, (100 - mi.availMem * 100 / mi.totalMem).toInt())
    }
}
