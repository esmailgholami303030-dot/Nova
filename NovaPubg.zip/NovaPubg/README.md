# NOVA PUBG
رابط کاربری همان فایل HTML است (app/src/main/assets/index.html). برای تغییر ظاهر فقط همان فایل را ویرایش کن.
داخل اپ، دکمه‌ی «روشن کردن DNS» از طریق NovaNative واقعاً DNS را با VPN محلی عوض می‌کند؛ در مرورگر معمولی فقط بهترین DNS را پیدا و کپی می‌کند.
بیلد: Android Studio ← Open ← Sync ← Run روی گوشی واقعی، یا GitHub Actions (پوشه‌ی .github).
